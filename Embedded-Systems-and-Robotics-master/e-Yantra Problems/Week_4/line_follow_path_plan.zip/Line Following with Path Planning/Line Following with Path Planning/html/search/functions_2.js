var searchData=
[
  ['servo_42',['servo',['../motor_8c.html#a61169cb60bbd6a60f0d17004b74e15d1',1,'servo(int value):&#160;motor.c'],['../motor_8h.html#a61169cb60bbd6a60f0d17004b74e15d1',1,'servo(int value):&#160;motor.c']]],
  ['servo_5fpin_5fconfig_43',['servo_pin_config',['../motor_8c.html#ae561eadfe722a84bc81077f0213819c9',1,'servo_pin_config(void):&#160;motor.c'],['../motor_8h.html#ae561eadfe722a84bc81077f0213819c9',1,'servo_pin_config(void):&#160;motor.c']]],
  ['speed_44',['speed',['../motor_8c.html#a7408e7e63f694ee1af501c4f41d81159',1,'speed(unsigned char speed_l, unsigned char speed_r):&#160;motor.c'],['../motor_8h.html#a7408e7e63f694ee1af501c4f41d81159',1,'speed(unsigned char speed_l, unsigned char speed_r):&#160;motor.c']]]
];
