var searchData=
[
  ['sbit_15',['sbit',['../motor_8c.html#a0e1a587a6bb537fb5e9c836231291df4',1,'sbit():&#160;motor.c'],['../sensors_8c.html#a0e1a587a6bb537fb5e9c836231291df4',1,'sbit():&#160;sensors.c']]],
  ['sensors_2ec_16',['sensors.c',['../sensors_8c.html',1,'']]],
  ['sensors_2eh_17',['sensors.h',['../sensors_8h.html',1,'']]],
  ['servo_18',['servo',['../motor_8c.html#a61169cb60bbd6a60f0d17004b74e15d1',1,'servo(int value):&#160;motor.c'],['../motor_8h.html#a61169cb60bbd6a60f0d17004b74e15d1',1,'servo(int value):&#160;motor.c']]],
  ['servo_5fpin_5fconfig_19',['servo_pin_config',['../motor_8c.html#ae561eadfe722a84bc81077f0213819c9',1,'servo_pin_config(void):&#160;motor.c'],['../motor_8h.html#ae561eadfe722a84bc81077f0213819c9',1,'servo_pin_config(void):&#160;motor.c']]],
  ['simulation_2eh_20',['simulation.h',['../simulation_8h.html',1,'']]],
  ['speed_21',['speed',['../motor_8c.html#a7408e7e63f694ee1af501c4f41d81159',1,'speed(unsigned char speed_l, unsigned char speed_r):&#160;motor.c'],['../motor_8h.html#a7408e7e63f694ee1af501c4f41d81159',1,'speed(unsigned char speed_l, unsigned char speed_r):&#160;motor.c']]]
];
