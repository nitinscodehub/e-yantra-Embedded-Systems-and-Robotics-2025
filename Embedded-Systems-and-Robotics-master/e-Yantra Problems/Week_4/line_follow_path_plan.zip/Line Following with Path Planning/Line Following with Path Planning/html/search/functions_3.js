var searchData=
[
  ['timer_5fpwm_5finit_45',['timer_pwm_init',['../motor_8c.html#a2142c3e44cf9a7e0dafea424dc93e1f9',1,'timer_pwm_init(void):&#160;motor.c'],['../motor_8h.html#a2142c3e44cf9a7e0dafea424dc93e1f9',1,'timer_pwm_init(void):&#160;motor.c']]],
  ['trigger_46',['trigger',['../sensors_8c.html#ab0554cb7241c0b72d34402f0bb419462',1,'trigger():&#160;sensors.c'],['../sensors_8h.html#ab0554cb7241c0b72d34402f0bb419462',1,'trigger():&#160;sensors.c']]]
];
