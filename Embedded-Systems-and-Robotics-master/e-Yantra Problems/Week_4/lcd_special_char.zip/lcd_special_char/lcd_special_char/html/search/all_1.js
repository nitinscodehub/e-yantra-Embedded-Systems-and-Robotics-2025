var searchData=
[
  ['db4_5fpin_1',['DB4_pin',['../simulation_8h.html#ad0ba9ca160e0007b2552b4edec8d4db1',1,'simulation.h']]],
  ['db5_5fpin_2',['DB5_pin',['../simulation_8h.html#a2403636f933dc95613a33312ced1ae65',1,'simulation.h']]],
  ['db6_5fpin_3',['DB6_pin',['../simulation_8h.html#a9041591874482064bc07af571ebc9878',1,'simulation.h']]],
  ['db7_5fpin_4',['DB7_pin',['../simulation_8h.html#a6b8ccc100efb2ba318d5f59f92e3651c',1,'simulation.h']]]
];
