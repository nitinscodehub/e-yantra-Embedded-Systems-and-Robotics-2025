var searchData=
[
  ['en_5fpin_5',['EN_pin',['../simulation_8h.html#a5a80b362ba1c2334940efcf8e04a1414',1,'simulation.h']]],
  ['experiment_3a_20lcd_5fspecial_5fchar_6',['Experiment: lcd_special_char',['../index.html',1,'']]]
];
