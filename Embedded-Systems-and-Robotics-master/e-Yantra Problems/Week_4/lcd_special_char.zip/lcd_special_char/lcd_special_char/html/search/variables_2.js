var searchData=
[
  ['temp_57',['temp',['../lcd_8c.html#a13006074294a071b6c7a268a498f77f7',1,'lcd.c']]],
  ['tens_58',['tens',['../lcd_8c.html#ab84b805352ca4b7ecfc9601ddab528bc',1,'lcd.c']]],
  ['thousand_59',['thousand',['../lcd_8c.html#aa790b5f78a8f90d800d64c46c3e40205',1,'lcd.c']]]
];
