var searchData=
[
  ['en_5fpin_66',['EN_pin',['../simulation_8h.html#a5a80b362ba1c2334940efcf8e04a1414',1,'simulation.h']]]
];
