var searchData=
[
  ['lcd_5fcontrol_5fddr_5freg_68',['lcd_control_ddr_reg',['../simulation_8h.html#a06bb1777260a75d83f4f11e01376ee14',1,'simulation.h']]],
  ['lcd_5fcontrol_5fport_5freg_69',['lcd_control_port_reg',['../simulation_8h.html#a0e1f95385a5073f7da0e7bed726c7493',1,'simulation.h']]],
  ['lcd_5fdata_5fddr_5freg_70',['lcd_data_ddr_reg',['../simulation_8h.html#a05b5fb46610da2e0ad73fbdbf39650a5',1,'simulation.h']]],
  ['lcd_5fdata_5fport_5freg_71',['lcd_data_port_reg',['../simulation_8h.html#a569962a363ef28bbff2ae0071703b00c',1,'simulation.h']]]
];
