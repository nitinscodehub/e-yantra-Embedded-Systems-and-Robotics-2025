var indexSectionsWithContent =
{
  0: "cdefhlmrstu",
  1: "ls",
  2: "lm",
  3: "hmtu",
  4: "cdeflrs",
  5: "e"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Macros",
  5: "Pages"
};

