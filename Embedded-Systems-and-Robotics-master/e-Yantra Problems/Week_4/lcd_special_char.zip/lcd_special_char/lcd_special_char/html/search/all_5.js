var searchData=
[
  ['lcd_2ec_9',['lcd.c',['../lcd_8c.html',1,'']]],
  ['lcd_2eh_10',['lcd.h',['../lcd_8h.html',1,'']]],
  ['lcd_5fchar_11',['lcd_char',['../lcd_8c.html#a1b58e67babad0e566ba0e3d188278612',1,'lcd_char(char alpha_num_char):&#160;lcd.c'],['../lcd_8h.html#a1b58e67babad0e566ba0e3d188278612',1,'lcd_char(char alpha_num_char):&#160;lcd.c']]],
  ['lcd_5fclear_12',['lcd_clear',['../lcd_8c.html#ad235a86241458b1e7b8771688bfdaf9a',1,'lcd_clear(void):&#160;lcd.c'],['../lcd_8h.html#ad235a86241458b1e7b8771688bfdaf9a',1,'lcd_clear(void):&#160;lcd.c']]],
  ['lcd_5fcontrol_5fddr_5freg_13',['lcd_control_ddr_reg',['../simulation_8h.html#a06bb1777260a75d83f4f11e01376ee14',1,'simulation.h']]],
  ['lcd_5fcontrol_5fport_5freg_14',['lcd_control_port_reg',['../simulation_8h.html#a0e1f95385a5073f7da0e7bed726c7493',1,'simulation.h']]],
  ['lcd_5fcursor_15',['lcd_cursor',['../lcd_8c.html#a58b03aa7464b2fb9b23e24fe8cd06df9',1,'lcd_cursor(char row, char column):&#160;lcd.c'],['../lcd_8h.html#a58b03aa7464b2fb9b23e24fe8cd06df9',1,'lcd_cursor(char row, char column):&#160;lcd.c']]],
  ['lcd_5fcustom_5fchar_16',['LCD_Custom_Char',['../lcd_8c.html#a6e5c72963efdd48dd7fc0b77c58c1ee2',1,'LCD_Custom_Char(unsigned char loc, unsigned char *msg):&#160;lcd.c'],['../lcd_8h.html#a6e5c72963efdd48dd7fc0b77c58c1ee2',1,'LCD_Custom_Char(unsigned char loc, unsigned char *msg):&#160;lcd.c']]],
  ['lcd_5fdata_5fddr_5freg_17',['lcd_data_ddr_reg',['../simulation_8h.html#a05b5fb46610da2e0ad73fbdbf39650a5',1,'simulation.h']]],
  ['lcd_5fdata_5fport_5freg_18',['lcd_data_port_reg',['../simulation_8h.html#a569962a363ef28bbff2ae0071703b00c',1,'simulation.h']]],
  ['lcd_5fhome_19',['lcd_home',['../lcd_8c.html#a3aabf730aa4e0393bb5c959583c00a8e',1,'lcd_home(void):&#160;lcd.c'],['../lcd_8h.html#a3aabf730aa4e0393bb5c959583c00a8e',1,'lcd_home(void):&#160;lcd.c']]],
  ['lcd_5finit_20',['lcd_init',['../lcd_8c.html#a6842775ba83d166f02b8fef8bb63b1e6',1,'lcd_init(void):&#160;lcd.c'],['../lcd_8h.html#a6842775ba83d166f02b8fef8bb63b1e6',1,'lcd_init(void):&#160;lcd.c']]],
  ['lcd_5fnumeric_5fvalue_21',['lcd_numeric_value',['../lcd_8c.html#a42e7ff80c1c9d5386704317aed355bf5',1,'lcd_numeric_value(char row, char column, int val, int digits):&#160;lcd.c'],['../lcd_8h.html#ad868b91f9c8a02386dce36e3aeb81e42',1,'lcd_numeric_value(char row, char coloumn, int val, int digits):&#160;lcd.c']]],
  ['lcd_5fport_5fconfig_22',['lcd_port_config',['../lcd_8c.html#af55f75f83e87baf043c835ef54412b99',1,'lcd_port_config(void):&#160;lcd.c'],['../lcd_8h.html#af55f75f83e87baf043c835ef54412b99',1,'lcd_port_config(void):&#160;lcd.c']]],
  ['lcd_5fset_5f4bit_23',['lcd_set_4bit',['../lcd_8c.html#ab6283000b2ac3f937db8c71da71d4aa6',1,'lcd_set_4bit(void):&#160;lcd.c'],['../lcd_8h.html#ab6283000b2ac3f937db8c71da71d4aa6',1,'lcd_set_4bit(void):&#160;lcd.c']]],
  ['lcd_5fspecial_5fchar_2ec_24',['lcd_special_char.c',['../lcd__special__char_8c.html',1,'']]],
  ['lcd_5fstring_25',['lcd_string',['../lcd_8c.html#af8972af25f0d5d2a6f4a0ab3bc801c1a',1,'lcd_string(char row, char column, char *str):&#160;lcd.c'],['../lcd_8h.html#af8972af25f0d5d2a6f4a0ab3bc801c1a',1,'lcd_string(char row, char column, char *str):&#160;lcd.c']]],
  ['lcd_5fwr_5fchar_26',['lcd_wr_char',['../lcd_8c.html#ad26780c46d4e4d8965fac988bcec8cbb',1,'lcd_wr_char(char row, char column, char alpha_num_char):&#160;lcd.c'],['../lcd_8h.html#a217915c66159944ea8e72e8870d88ad2',1,'lcd_wr_char(char row, char coloumn, char alpha_num_char):&#160;lcd.c']]],
  ['lcd_5fwr_5fcommand_27',['lcd_wr_command',['../lcd_8c.html#ab6854332b00474f8d1c39b66467d17a8',1,'lcd_wr_command(unsigned char cmd):&#160;lcd.c'],['../lcd_8h.html#ab6854332b00474f8d1c39b66467d17a8',1,'lcd_wr_command(unsigned char cmd):&#160;lcd.c']]]
];
