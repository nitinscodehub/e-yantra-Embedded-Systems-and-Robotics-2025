var searchData=
[
  ['rs_5fpin_30',['RS_pin',['../simulation_8h.html#a93c40d470c77d475f2c695057f6bc974',1,'simulation.h']]],
  ['rw_5fpin_31',['RW_pin',['../simulation_8h.html#af4f1ff3d6f722489a18b161e79a41c53',1,'simulation.h']]]
];
